# Program 378
# Category: strings
# Description: Sample DSA program template

def main():
    data = input("Enter input: ")
    print("You entered:", data)

if __name__ == "__main__":
    main()
