# Program 254
# Category: arrays
# Description: Sample DSA program template

def main():
    data = input("Enter input: ")
    print("You entered:", data)

if __name__ == "__main__":
    main()
